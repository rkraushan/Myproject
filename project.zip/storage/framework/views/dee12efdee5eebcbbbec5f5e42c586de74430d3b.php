<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="https://unpkg.com/treeflex/dist/css/treeflex.css">
<style type="text/css">
  .example .tf-nc {
  /* css here */
}

.tf-custom .tf-nc:before,
.tf-custom .tf-nc:after {
  /* css here */
}

.tf-custom li li:before {
  /* css here */
}
</style>
    <div class="page-body">

        <!-- Container-fluid starts-->
        <div class="container-fluid">
            <div class="page-header">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="page-header-left">
                            <h3>JLM Members
                                <small> Admin panel</small>
                            </h3>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <ol class="breadcrumb pull-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>"><i data-feather="home"></i></a></li>
                            <li class="breadcrumb-item">Members</li>
                            
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <!-- Container-fluid Ends-->

        <!-- Container-fluid starts-->
        <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                   <?php 
                     $level1= getUsersbySponserId($admin->self_id);
                    ?>
                    
                    
                    <div class="tf-tree example">
                        <ul>
                            <li>
                                <span class="tf-nc"><?php echo e($admin->name); ?></span>
                                <ul>
                                  <?php $__currentLoopData = $level1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li>
                                    <span class="tf-nc"><?php echo e($level->name); ?></span>
                                    <ul>
                                    <?php 
                                        $level2= getUsersbySponserId($level->self_id);
                                    ?> 
                                      <?php $__currentLoopData = $level2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level21): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <li><span class="tf-nc"><?php echo e($level21->name); ?></span></li>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                  </li>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!--                                  <li>
                                    <span class="tf-nc">3</span>
                                    <ul>
                                      <li><span class="tf-nc">7</span></li>
                                      <li><span class="tf-nc">8</span></li>
                                    </ul>
                                  </li>-->
                                </ul>
                            </li>
                        </ul>
                  </div>
                </div>
            </div>
        </div>
        <!-- Container-fluid Ends-->
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dlqsb80rhkzg/public_html/project/resources/views/admin/tree-view.blade.php ENDPATH**/ ?>