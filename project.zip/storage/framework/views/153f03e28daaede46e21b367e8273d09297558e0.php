<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head><meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"><link rel="alternate" hreflang="en_US" href="<?php echo e(url('/')); ?>" />
	<link media="all" href="css/style.css" rel="stylesheet" />
	<title>PK Enterprises: #1 Multilevel Marketing Business Solution and Health Care Product Manufacturer Company </title>
	<meta name="description" content="PK Enterprises multilevel marketing business solution and health care product manufacturer company" />
	<meta name="robots" content="index, follow" />

 
 <link rel="icon" href="image/logo21.png" sizes="32x32" />
 <link rel="icon" href="image/logo21.png" sizes="192x192" />
 <link rel="apple-touch-icon" href="image/logo21.png" />
 <meta name="msapplication-TileImage" content="image/logo21.png" />
 <script defer src="js/script.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link media="all" href="css/customstyle.css" rel="stylesheet" />
</head> 
  <body class="home page-template page-template-front-page page-template-front-page-php page page-id-154 wp-custom-logo twentyseventeen-front-page has-header-image page-two-column colors-light en">
    <header>
        <div class="container">
	        <div class="language-mobile">
	          <div class="mob-lang-container">
	            
	          </div>
	        </div>
			<div class="logo">
			  <a class="" href="<?php echo e(url('/')); ?>">
			  	<img   class="lazyload" src="image/logo21.png" style="height: 56px;">
			  </a>   
			</div>
		    <div class="main-nav"> 
		        <div id="cssmenu" class="menu-main-menu-container">
		        	<ul id="menu-main-menu" class="menu">
			          	<li id="menu-item-258" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-154 current_page_item menu-item-258 active "><a href="<?php echo e(url('/')); ?>" aria-current="page">HOME</a></li>

			          	<li id="menu-item-2767" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2767"><a href="<?php echo e(url('about')); ?>">About Us</a></li>
			             
			            <li id="menu-item-2768" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2768"><a href="<?php echo e(url('our-products')); ?>">Products</a></li>

			         <!--   <li id="menu-item-3217" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3217"><a  href="<?php echo e(url('team')); ?>">Team</a></li>-->

			          	<li id="menu-item-2766" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2766"><a href="<?php echo e(url('contact')); ?>">Contact Us</a></li>
			                <?php if(auth()->guard()->guest()): ?>
                                        
                                        <li id="menu-item-5939" class="get-started-now menu-item menu-item-type-post_type menu-item-object-page menu-item-5939"><a href="<?php echo e(route('login')); ?>">Login Now</a></li>
					<?php else: ?>
                                        <li class="nav-item dropdown">
                                            <a id="navbarDropdown" class="nav-link" href="<?php echo e(Auth::user()->user_type); ?>" role="button">
                                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        </ul>
				</div>      
			</div>
 		 </div>
    </header>
    <!-- END header -->
    
    
    <?php echo $__env->yieldContent('content'); ?>

<!-- END section -->


<section class="footer-social-section">
  <div class="container">
    <div class="footer-social">
            <div class="widget_text "><div class="textwidget custom-html-widget">	<a class="applink" target="_black" href="#" rel="noopener noreferrer"><i class="fa fa-android" aria-hidden="true"></i><h3 class="and-tx">Android</h3><span>Available Soon</span>
</a>
</div></div>
<div class="widget_text "><div class="textwidget custom-html-widget">	<a class="applink" target="_black" href="#" rel="noopener noreferrer"><i class="fa fa-apple" aria-hidden="true"></i><h3 class="and-tx">iOS</h3><span>Available Soon</span></a></div>
</div><div class="widget_text "><div class="textwidget custom-html-widget"><h4 class="prefix">Don't miss our latest updates!</h4>
<form accept-charset="UTF-8" action="" id="newsletter-subscribe-form" method="post" onsubmit="" target="popupwindow">
  <div>
    <input name="uri" type="hidden" value="InfiniteMlmSoftware"><input name="loc" type="hidden" value="en_US">
      <div class="newsletter-input"><input class="form-text required" id="edit-email" maxlength="128" name="email" onblur="" onfocus="" placeholder="abc@gmail.com" required="" size="20" type="email">
      </div>
      <div id="subscribe" class="newsletter-button">
        <input class="form-submit" id="edit-newsletter-submit" name="op" type="submit" value="Subscribe">
      </div>
      <div>
        <input name="form_build_id" type="hidden" value="form--zl-T2rINNu03leWMgyr1M31a-0TbuxIhzpYRiawgQM"><input name="form_id" type="hidden" value="newsletter_subscribe_form">
      </div>
  </div>
  <div id="newsletter-error"></div>
</form></div></div><div class="widget_text "><div class="textwidget custom-html-widget"><h4 class="social-p">Social</h4>
<ul class="social-list">
  <li><a target="_blank" href="#" rel="noopener noreferrer"><span class="fa fa-facebook"></span></a></li>
  <li><a target="_blank" href="#" rel="noopener noreferrer"><span class="fa fa-twitter"></span></a></li>
  <li><a target="_blank" href="#" rel="noopener noreferrer"><span class="fa fa-linkedin"></span></a></li>
  <li><a target="_blank" href="#" rel="noopener noreferrer"><span class="fa fa-youtube"></span></a></li>
  <li><a target="_blank" href="#" rel="noopener noreferrer"><span class="fa fa-instagram"></span></a></li>
</ul></div></div>          </div>
  </div>
</section>

<footer class="site-footer" role="contentinfo">
  <div class="container">
    <div class="footer-container">
      <div class="footer-cnt">
                    
        <div class="widget_text "><h3>PK Enterprises</h3><div class="textwidget custom-html-widget">
        <li class="at-on"><span class="cl-wid">&#x2726;</span><a href="<?php echo e(url('contact')); ?>">Contact Us</a></li>
<li class="at-on"><span class="cl-wid">&#x2726;</span><a href="<?php echo e(url('about')); ?>">About Us</a></li>
<li class="at-on"><span class="cl-wid">&#x2726;</span><a href="<?php echo e(url('sitemap')); ?>">Sitemap</a></li>
<li class="at-on"><span class="cl-wid">&#x2726;</span><a href="<?php echo e(url('term')); ?>">Terms</a></li>
<li class="at-on"><span class="cl-wid">&#x2726;</span><a href="<?php echo e(url('refund-policy')); ?>">Refund Policy</a></li></div></div>              </div>
      <div class="footer-cnt">
                    
        <div class="widget_text "><h3>Our Products</h3><div class="textwidget custom-html-widget">
        <li class="at-on"><span class="cl-wid">✦</span><a href="<?php echo e(url('our-products')); ?>">Teeth Health</a></li>
 	<li class="at-on"><span class="cl-wid">✦</span><a href="<?php echo e(url('our-products')); ?>">Divya Ratn Oil</a></li>
 	<li class="at-on"><span class="cl-wid">✦</span><a href="<?php echo e(url('our-products')); ?>">Divya kranti Oil</a></li>
 	<li class="at-on"><span class="cl-wid">✦</span><a href="<?php echo e(url('our-products')); ?>">Deep Malham</a></li>
 	<li class="at-on"><span class="cl-wid">✦</span><a href="<?php echo e(url('our-products')); ?>">View All Products</a></li></div></div>              </div>
      <div class="footer-cnt">
                <div class="widget_text "><h3>Quick Links</h3><div class="textwidget custom-html-widget"><li class="at-on"><span class="cl-wid">✦</span><a href="<?php echo e(url('about')); ?>">MLM Features</a></li>
 	<li class="at-on"><span class="cl-wid">✦</span><a href="<?php echo e(url('team')); ?>">Our Team</a></li>
 	<li class="at-on"><span class="cl-wid">✦</span><a href="<?php echo e(url('marketing-strategy')); ?>">Marketing Strategy</a></li>
 	<li class="at-on"><span class="cl-wid">✦</span><a href="#" >Our Blogs</a></li>
	<li class="at-on"><span class="cl-wid">✦</span><a href="<?php echo e(url('faq')); ?>">FAQ</a></li></div></div>              </div>
      <div class="footer-cnt">
                <div class="widget_text "><h3>FOLLOW US</h3><div class="textwidget custom-html-widget"><div class="on-contacts">
    <li><i class="fa fa-whatsapp"></i> <a href="https://api.whatsapp.com/send?phone=918789543127" method="get" target="_blank" rel="noopener noreferrer"> +91 8789543127</a></li>
    <li><i class="fa fa-whatsapp"></i> <a href="https://api.whatsapp.com/send?phone=918084717511" method="get" target="_blank" rel="noopener noreferrer"> +91 8084717511</a>
</li>
<li><i class="fa fa-envelope"></i> guddusinghrks1@gmail.com</li>
<!-- <li><i class="fa fa-skype"></i> <a href="skype:pkenterprises?chat"> pkenterprises</a></li> -->
</div></div></div>              </div>
    </div>
    
  </div>
  <div class="copyright">
    <div class="container">
            <div class="widget_text "><div class="textwidget custom-html-widget"><p>
© Copyright 2020 by <a href="http://pkenterprises.in/">PK Enterprises  </a> All Rights Reserved.</p></div></div>          </div>
  </div>
</footer>
<!-- END footer -->

<script src="js/frontend.min.js" defer="defer" type="text/javascript"></script>
<script src="js/smush-lazy-load.min.js" defer="defer" type="text/javascript"></script>
<script src="js/wp-embed.min.js" defer="defer" type="text/javascript"></script>
	
</body>
</html><?php /**PATH /home/dlqsb80rhkzg/public_html/project/resources/views/frontend.blade.php ENDPATH**/ ?>