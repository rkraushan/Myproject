
<?php $__env->startSection('content'); ?>
<link media="all" href="css/contact.css" rel="stylesheet" />
<section class="sub-banner-section">
  <div class="container">
    <div class="sub-banner-heading">
      <h1 class="">Contact Us</h1>
    </div>
    <div class="breadcrumb"><a href="<?php echo e(url('/')); ?>">Home</a>&nbsp;&nbsp;&#187;&nbsp;&nbsp;Contact Us</div>
  </div>
</section>
<main>
<section class="contact-page">
    <div class="container" >        
    <div class="contact-container">
        <div class="contact-form">
            <div role="form" class="wpcf7" id="wpcf7-f985-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response" aria-live="polite"></div>
<form action="#" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="985" />
<input type="hidden" name="_wpcf7_version" value="5.1.9" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f985-o1" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="g-recaptcha-response" value="" />
</div>
<div class="row">
<div class="col-md-6 col-xs-12"><label> Your Name *<br />
    <span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="100" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-control" aria-required="true" aria-invalid="false" /></span> </label></div>
<div class="col-md-6 col-xs-12"><label> Your Email Address *<br />
    <span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="100" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email form-control" aria-required="true" aria-invalid="false" /></span> </label></div>
<div class="col-md-6 col-xs-12"><label> Subject *<br />
    <span class="wpcf7-form-control-wrap your-subject"><input type="text" name="your-subject" value="" size="100" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-control" aria-required="true" aria-invalid="false" /></span> </label></div>
<div class="col-md-6 col-xs-12"><label> Phone *<br />
    <span class="wpcf7-form-control-wrap Phone"><input type="tel" name="Phone" value="" size="100" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel form-control" aria-required="true" aria-invalid="false" /></span> </label></div>

<div class="col-md-6 col-xs-12">
<label> Address *<br />
    <span class="wpcf7-form-control-wrap Country">
        <input type="text" name="Countryt" value="" style="width: 545px !important;" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required form-control" aria-required="true" aria-invalid="false" /></span> </label></div>
    
<div class="col-md-12 col-xs-12"><label> Message *<br />
    <span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="100" rows="8" class="wpcf7-form-control wpcf7-textarea wpcf7-validates-as-required form-control" aria-required="true" aria-invalid="false"></textarea></span> </label></div>
<div class="col-md-12 col-xs-12"><input type="submit" value="Submit" class="wpcf7-form-control wpcf7-submit primary-btn contact-submit col-md-12" id="Submit" /></div>
</div>
<div class="wpcf7-response-output wpcf7-display-none" aria-hidden="true"></div></form></div></div><div class="contact-adrs"><h4>CONTACT INFORMATION</h4>
<p><strong>Feel free to contact us</strong></p>
<div class="row">
<div class="col-md-6 contact_address">
<div class="box-icon"><i class="fa fa-map-marker"></i></p>
<h4>India</h4>
</div>
<p>		PK Enterprises<br />
		Unit No 01,2nd floor, "Ramesh Chowk",<br />
		Aurangabad - 824101, Bihar, India
	</p></div>
<div class="col-md-6 phone">
<div class="box-icon"><i class="fa fa-phone"></i></p>
<h4>Phone Number</h4>
</div>
<p>	+91 8789543127 <br/>	
        +91 8084717511<br />
		
	</p></div>

<div class="col-md-6 email">
<div class="box-icon"><i class="fa fa-envelope-o"></i></p>
<h4>Email</h4>
</div>
<p>Gmail ID: guddusinghrks1@gmail.com </p></div>

<div class="col-md-6 skype">
<div class="box-icon"><i class="fa fa-skype"></i></p>
<h4>Skype ID</h4>
</div>
<p>pkenterprises</p></div>
</div>
</div></div>
</div>

</div>
<div class="location-container">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d28985.45109188384!2d84.3608373390353!3d24.754969282621158!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x398cfc35b57ffe31%3A0xffea2031cb937478!2sAurangabad%2C%20Bihar!5e0!3m2!1sen!2sin!4v1592059861099!5m2!1sen!2sin" class="embed-responsive-item lazyload"  frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        
    </div>
</section>
</main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dlqsb80rhkzg/public_html/project/resources/views/contact.blade.php ENDPATH**/ ?>