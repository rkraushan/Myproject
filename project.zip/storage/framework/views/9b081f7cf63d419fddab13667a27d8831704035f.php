<?php $__env->startSection('content'); ?>

<section class="sub-banner-section">
  <div class="container">
    <div class="sub-banner-heading">
      <h1 class="">About Us</h1>
    </div>
    <div class="breadcrumb"><a href="<?php echo e(url('/')); ?>">Home</a>&nbsp;&nbsp;&#187;&nbsp;&nbsp;About Us</div>
  </div>
</section>

<main>

        <section class="vertion-area">
  <div class="container">
    <div class="about-head">
      <h3>Searching for a <span class="text-danger"> Reliable and Advanced</span> MLM Software?</h3>
      <p class="text-center">Want to invest in a good MLM Software for managing your network marketing business? We are here to save your day!</p>
    </div>
    <div class="row">
      <div class="col-lg-7">
        <div class="content">
          <p><a href="<?php echo e(url('/')); ?>">PK Enterprises</a> is a Certified and a premier multilevel marketing company based at Aurangabad Bihar, India. We started out as a team of four members and has now spread into a company of more than 1000 JLM members. Formed in 2019 with a vision of using marketing innovation to communicate jeevan life marketing solution and health care medicine with is pure natural ayurvedic medicine, we have reached the pinnacle in the industry. We have a global presence with our business office based in Aurangabad and our aims to works on across all over india.</p>
          <p><a href="<?php echo e(url('/')); ?>">PK Enterprises</a> is our best selling product with state of art features and substantial options for customization as per client’s requirement. Our Network Marketing Software is available with the wide range of MLM business strategy and medical facility with pure natural product.</p>
        </div>
      </div>
      <div class="col-md-5 mt-2 mb-4">
        <img  class="lazyload" src="image/client.jpg" height="260px;">
      </div>
      <div class="col-lg-12">
        <div class="content">
          <p>Our team members are experts in business development and medical skills. We are always trying to focus quality based healthy product as per customer demands. We are provide happy environment for business developement which is done by highly remarkable skilled managemnet team. As a company built on the ideals of superior quality and complete customer satisfaction, we are very particular to provide top class solutions to all your demands. </p>
        </div>
      </div>
    </div>
  </div>
</div>
<section class="vison-mission">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <div class="vision">
          <h3>Our Vision</h3>
          <ul class="bullet-icon">
            <li>To be the first choice in the industry for the development of any software, keeping innovation in par with cost effectiveness.</li>
            <li>To earn global recognition by consistently delivering quality products and continuous improvement in quality of workforce.</li>
            <li>Lend a helping hand to the underprivileged and fulfill the social responsibility we owe to the world.</li>
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="mission">
          <h3>Our Mission</h3>
          <ul class="bullet-icon">
            <li>Market defining solutions to real time problems.</li>
            <li>Delivery of premium software products as per client’s requirements.</li>
            <li>Creative and out of the box thinking.</li>
            <li>Cent percent customer satisfaction.</li>
            <li>Superior quality products in cost effective manner.</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="development-process-sesction">
  <div class="container">
    <h3 class="why-chs text-center">How Business Development and Product Manufaturing Process Begins?</h3>
    <div class="development-process">
      <div class="deve-process-container">
        <div class="deve-pro-cnt">
          <div class="deve-pro-count"><span>1</span></div>
          <div class="deve-pro-count-img"><img   class="lazyload" src="image/team.png"></div>
          <h3 class="deve-pro-head">Planning &#038; Requirement gathering</h3>
        </div>
        <div class="deve-pro-cnt">
          <div class="deve-pro-count"><span>2</span></div>
          <div class="deve-pro-count-img"><img   class="lazyload" src="image/Professional.png"></div>
          <h3 class="deve-pro-head">System analysis</h3>
        </div>
        <div class="deve-pro-cnt">
          <div class="deve-pro-count"><span>3</span></div>
          <div class="deve-pro-count-img"><img   class="lazyload" src="image/Professional.png"></div>
          <h3 class="deve-pro-head">System Design</h3>
        </div>
        <div class="deve-pro-cnt">
          <div class="deve-pro-count"><span>4</span></div>
          <div class="deve-pro-count-img"><img  class="lazyload" src="image/work-together.png"></div>
          <h3 class="deve-pro-head">Development and Implementation</h3>
        </div>
        <div class="deve-pro-cnt">
          <div class="deve-pro-count"><span>5</span></div>
          <div class="deve-pro-count-img"><img   class="lazyload" src="image/High-quality.png"></div>
          <h3 class="deve-pro-head">Testing</h3>
        </div>
        <div class="deve-pro-cnt">
          <div class="deve-pro-count"><span>6</span></div>
          <div class="deve-pro-count-img"><img   class="lazyload" src="image/assistance.png"></div>
          <h3 class="deve-pro-head">Maintenance</h3>
        </div>
        <div class="deve-pro-cnt deve-pro-cnt-last">
          <div class="deve-pro-count"><span>7</span></div>
          <div class="deve-pro-count-img"><img  alt=""  class="lazyload" src="image/Delive-client.jpg"></div>
          <h3 class="deve-pro-head">Deliver to client</h3>
        </div>
      </div>
    </div>
  </div>
</section>

</section>        

</main>
<!-- END section -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dlqsb80rhkzg/public_html/project/resources/views/about.blade.php ENDPATH**/ ?>