<?php $__env->startSection('content'); ?>
    <div class="page-body">

        <!-- Container-fluid starts-->
        <div class="container-fluid">
            <div class="page-header">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="page-header-left">
                            <h3>JLM Members
                                <small> Admin panel</small>
                            </h3>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <ol class="breadcrumb pull-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('admin')); ?>"><i data-feather="home"></i></a></li>
                            <li class="breadcrumb-item">Members</li>
                            
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <!-- Container-fluid Ends-->

        <!-- Container-fluid starts-->
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <h5>Details</h5>
                    <div class="btn-popup pull-right">
                        <a href="<?php echo e(url('admin/new-user')); ?>" class="btn btn-secondary">Create User</a>
                    </div>
                </div>
                <div class="card-body">
                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th>SN.</th>
                                <th>Sponsor ID</th>
                                <th>Sponsor Name</th>
                                <th>Member Id</th>
                                <th>Name</th>
                                <th>Father</th>
                                <th>Mobile</th>
                                <th>Address</th>
                                <th>A/C Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                             <?php $i=0;?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php $i++;?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($user->sponsor_id); ?></td>
                                    <td><?php echo e($user->sponsor_name); ?></td>
                                    <td><?php echo e($user->self_id); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->father_name); ?></td>
                                    <td><?php echo e($user->mobile_no); ?></td>
                                    <td><?php echo e($user->village .' '.$user->district); ?></td>
                                    <td><?php if($user->payment_status == 0){
                                        echo "<span  class='btn btn-warning'>IN ACTIVE</span>";
                                    }else{
                                        echo "<span style='color:white' class='btn btn-success'> ACTIVE</span>";
                                    }
?></td>
                                   
                                    <td><a href="<?php echo e(url('admin/view-user/'.$user->id)); ?>" >View</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
              
                </div>
            </div>
        </div>
        <!-- Container-fluid Ends-->
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dlqsb80rhkzg/public_html/project/resources/views/admin/users.blade.php ENDPATH**/ ?>