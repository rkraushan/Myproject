
<?php $__env->startSection('content'); ?>
<link media="all" href="css/feature.css" rel="stylesheet" />

    <section class="sub-banner-section">
  <div class="container">
    <div class="sub-banner-heading">
      <h1 class="">Our Products</h1>
    </div>
    <div class="breadcrumb"><a href="<?php echo e(url('/')); ?>">Home</a>&nbsp;&nbsp;&#187;&nbsp;&nbsp;Our Products</div>
  </div>
</section>
    <!-- start product-area-->
    <main>
        <section class="section top-old">
        <div class="container">		
            <div class="row features-page">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--Gallery Item-->
                    <div class="features-page-container">
                        <div class="core-feature-single">
                            <div class="features_box">
                               
                            <a><img src="<?php echo e(asset('productImage/'.$product->image)); ?>" alt=""  class="pull-left lazyload" > </a>
                               
                                    <a href="#"><h5><strong><?php echo e($product->name); ?> </strong></h5></a>
                                <p>Uses: <?php echo e(wordwrap($product->description,20)); ?></p>
                                <h6>Rs <?php echo e($product->price); ?></h6>
                                <a><button class="add-to-cart-btn">Add To Cart</button></a>
                            </div>
                            
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
	</div>
    </section>
    </main>
    <!-- end product-area-->
    
<?php $__env->stopSection(); ?>
   

<?php echo $__env->make('frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dlqsb80rhkzg/public_html/project/resources/views/products.blade.php ENDPATH**/ ?>