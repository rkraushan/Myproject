@extends('frontend')
@section('content')
<link media="all" href="css/feature.css" rel="stylesheet" />

    <section class="sub-banner-section">
  <div class="container">
    <div class="sub-banner-heading">
      <h1 class="">Our Products</h1>
    </div>
    <div class="breadcrumb"><a href="{{url('/')}}">Home</a>&nbsp;&nbsp;&#187;&nbsp;&nbsp;Our Products</div>
  </div>
</section>
    <!-- start product-area-->
    <main>
        <section class="section top-old">
        <div class="container">		
            <div class="row features-page">
                @foreach($products as $product)
                    <!--Gallery Item-->
                    <div class="features-page-container">
                        <div class="core-feature-single">
                            <div class="features_box">
                               
                            <a><img src="{{asset('productImage/'.$product->image)}}" alt=""  class="pull-left lazyload" > </a>
                               
                                    <a href="#"><h5><strong>{{$product->name}} </strong></h5></a>
                                <p>Uses: {{wordwrap($product->description,20)}}</p>
                                <h6>Rs {{$product->price}}</h6>
                                <a><button class="add-to-cart-btn">Add To Cart</button></a>
                            </div>
                            
                        </div>
                    </div>
                @endforeach
            </div>
	</div>
    </section>
    </main>
    <!-- end product-area-->
    
@endsection
   
