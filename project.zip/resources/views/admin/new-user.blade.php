@extends('admin.dashboard')
@section('content')
<div class="page-body">

    <!-- Container-fluid starts-->
    <div class="container-fluid">
        <div class="page-header">
            <div class="row">
                <div class="col-lg-6">
                    <div class="page-header-left">
                        <h3>Create User
                            <small>Admin panel</small>
                        </h3>
                    </div>
                </div>
                <div class="col-lg-6">
                    <ol class="breadcrumb pull-right">
                        <li class="breadcrumb-item"><a href="{{url('admin')}}"><i data-feather="home"></i></a></li>
                        <li class="breadcrumb-item">Users </li>
                        <li class="breadcrumb-item active">Create User </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!-- Container-fluid Ends-->

    <!-- Container-fluid starts-->
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card tab2-card">
                    <div class="card-header">
                        <h5> Add User</h5>
                    </div>
                    <div class="card-body">
                        
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade active show" id="account" role="tabpanel" aria-labelledby="account-tab">
                                <form class="needs-validation user-add" action="{{url('admin/reg-new-user')}}" method="post" enctype="multipart/form-data">
                                    @csrf
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="sponsor_id" class="col-xl-3 col-md-4"><span>*</span> Sponsor ID:</label>
                                                <input name="sponsor_id" class="form-control col-xl-8 col-md-7 @error('sponsor_id') is-invalid @enderror" id="sponsor_id" type="text" required="" value="{{ old('sponsor_id') }}" autofocus>
                                                @error('sponsor_id')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <label for="sponsor_name" class="col-xl-3 col-md-4"><span>*</span> Sponsor Name:</label>
                                                <input name="sponsor_name" class="form-control col-xl-8 col-md-7 @error('sponsor_name') is-invalid @enderror" id="sponsor_name" type="text" required="" value="{{ old('sponsor_name') }}" autofocus>
                                                @error('sponsor_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="citizen" class="col-xl-3 col-md-4"><span>*</span> Citizen:</label>
                                                <div class="col-xl-8 col-md-7">
                                                    Mr: <input name="citizen" class=" @error('citizen') is-invalid @enderror" id="citizen" type="radio" required="" value="Mr" autofocus>
                                                    Mrs: <input name="citizen" class=" @error('citizen') is-invalid @enderror" id="citizen" type="radio" required="" value="Mrs" autofocus>
                                                </div>
                                                @error('citizen')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <label for="gender" class="col-xl-3 col-md-4"><span>*</span> Gender:</label>
                                                <div class="col-xl-8 col-md-7">
                                                   Male: <input name="gender" class=" @error('gender') is-invalid @enderror" id="gender" type="radio" required="" value="Male" autofocus>
                                                   Female: <input name="gender" class=" @error('gender') is-invalid @enderror" id="gender" type="radio" required="" value="Female" autofocus>
                                                </div>
                                                @error('gender')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="name" class="col-xl-3 col-md-4"><span>*</span> Name:</label>
                                                <input name="name" class="form-control col-xl-8 col-md-7 @error('name') is-invalid @enderror" id="name" type="text" required="" value="{{ old('name') }}" autofocus>
                                                @error('name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <label for="father_name" class="col-xl-3 col-md-4"><span>*</span> Father Name:</label>
                                                <input name="father_name" class="form-control col-xl-8 col-md-7 @error('father_name') is-invalid @enderror" id="father_name" type="text" required="" value="{{ old('father_name') }}" autofocus>
                                                @error('father_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                        
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <label for="email" class="col-xl-3 col-md-4"><span>*</span> Email:</label>
                                                <input name="email" class="form-control col-xl-8 col-md-7 @error('email') is-invalid @enderror" id="email" type="text" required="" value="{{ old('email') }}" autofocus>
                                                @error('email')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="password" class="col-xl-3 col-md-4"><span>*</span> Password:</label>
                                                <input name="password" class="form-control col-xl-8 col-md-7 @error('password') is-invalid @enderror" id="password" type="text" required="" value="{{ old('password') }}" autofocus>
                                                @error('password')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                        
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="pan_no" class="col-xl-3 col-md-4"><span>*</span> Pan No:</label>
                                                <input name="pan_no" class="form-control col-xl-8 col-md-7 @error('pan_no') is-invalid @enderror" id="pan_no" type="text"  value="{{ old('pan_no') }}" autofocus>
                                                @error('pan_no')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <label for="dob" class="col-xl-3 col-md-4"><span>*</span> DOB:</label>
                                                <input name="dob" class="form-control col-xl-8 col-md-7 @error('dob') is-invalid @enderror" id="dob" type="date" required="" value="{{ old('dob') }}" autofocus>
                                                @error('dob')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="village" class="col-xl-3 col-md-4"><span>*</span> Village:</label>
                                                <input name="village" class="form-control col-xl-8 col-md-7 @error('village') is-invalid @enderror" id="village" type="text" required="" value="{{ old('village') }}" autofocus>
                                                @error('village')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <label for="post_office" class="col-xl-3 col-md-4"><span>*</span> Post Office:</label>
                                                <input name="post_office" class="form-control col-xl-8 col-md-7 @error('post_office') is-invalid @enderror" id="post_office" type="text" required="" value="{{ old('post_office') }}" autofocus>
                                                @error('post_office')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="police_station" class="col-xl-3 col-md-4"><span>*</span> Police Station:</label>
                                                <input name="police_station" class="form-control col-xl-8 col-md-7 @error('police_station') is-invalid @enderror" id="police_station" type="text" required="" value="{{ old('police_station') }}" autofocus>
                                                @error('police_station')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <label for="district" class="col-xl-3 col-md-4"><span>*</span> District:</label>
                                                <input name="district" class="form-control col-xl-8 col-md-7 @error('district') is-invalid @enderror" id="district" type="text" required="" value="{{ old('district') }}" autofocus>
                                                @error('district')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="state" class="col-xl-3 col-md-4"><span>*</span> State:</label>
                                                <input name="state" class="form-control col-xl-8 col-md-7 @error('state') is-invalid @enderror" id="state" type="text" required="" value="{{ old('state') }}" autofocus>
                                                @error('state')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <label for="pincode" class="col-xl-3 col-md-4"><span>*</span> Pincode:</label>
                                                <input name="pincode" class="form-control col-xl-8 col-md-7 @error('pincode') is-invalid @enderror" id="pincode" type="text" required="" value="{{ old('pincode') }}" autofocus>
                                                @error('pincode')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="aadhar_no" class="col-xl-3 col-md-4"><span>*</span> Aadhar No:</label>
                                                <input name="aadhar_no" class="form-control col-xl-8 col-md-7 @error('aadhar_no') is-invalid @enderror" id="aadhar_no" type="number" required="" value="{{ old('aadhar_no') }}" autofocus>
                                                @error('aadhar_no')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <label for="mobile_no" class="col-xl-3 col-md-4"><span>*</span> Mobile No:</label>
                                                <input name="mobile_no" class="form-control col-xl-8 col-md-7 @error('mobile_no') is-invalid @enderror" id="mobile_no" type="text" required="" value="{{ old('mobile_no') }}" autofocus>
                                                @error('mobile_no')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <!--<div class="form-group row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="profile_pic" class="col-xl-3 col-md-4"><span>*</span> Profile Pic:</label>
                                                <input name="profile_pic" class="form-control col-xl-8 col-md-7 @error('profile_pic') is-invalid @enderror" id="profile_pic" type="file"  value="{{ old('profile_pic') }}" autofocus>
                                                @error('profile_pic')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <label for="signature" class="col-xl-3 col-md-4"><span>*</span> Signature:</label>
                                                <input name="signature" class="form-control col-xl-8 col-md-7 @error('signature') is-invalid @enderror" id="signature" type="file"  value="{{ old('signature') }}" autofocus>
                                                @error('signature')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                    </div> -->
                                    
                                    <h4>Bank Account Details</h4>
                                    <br/>
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="account_holder_name" class="col-xl-3 col-md-4"><span>*</span>Name:</label>
                                                <input name="account_holder_name" class="form-control col-xl-8 col-md-7 @error('account_holder_name') is-invalid @enderror" id="account_holder_name" type="text"  value="{{ old('account_holder_name') }}" autofocus>
                                                @error('account_holder_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <label for="branch_name" class="col-xl-3 col-md-4"><span>*</span> Branch Name:</label>
                                                <input name="branch_name" class="form-control col-xl-8 col-md-7 @error('branch_name') is-invalid @enderror" id="branch_name" type="text"  value="{{ old('branch_name') }}" autofocus>
                                                @error('branch_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="branch_ifsc" class="col-xl-3 col-md-4"><span>*</span> IFSC Code:</label>
                                                <input name="branch_ifsc" class="form-control col-xl-8 col-md-7 @error('branch_ifsc') is-invalid @enderror" id="branch_ifsc" type="text"  value="{{ old('branch_ifsc') }}" autofocus>
                                                @error('branch_ifsc')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <label for="account_no" class="col-xl-3 col-md-4"><span>*</span> A/C No:</label>
                                                <input name="account_no" class="form-control col-xl-8 col-md-7 @error('account_no') is-invalid @enderror" id="account_no" type="text"  value="{{ old('account_no') }}" autofocus>
                                                @error('account_no')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="bank_name" class="col-xl-3 col-md-4"><span>*</span> Bank Name:</label>
                                                <input name="bank_name" class="form-control col-xl-8 col-md-7 @error('bank_name') is-invalid @enderror" id="bank_name" type="text"  value="{{ old('bank_name') }}" autofocus>
                                                @error('bank_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                        
                                    </div>
                                    
                                    <h4>Nominee Details</h4>
                                    
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                            <div class="row">
                                                <label for="nominee_name" class="col-xl-3 col-md-4"><span>*</span> Nominee Name:</label>
                                                <input name="nominee_name" class="form-control col-xl-8 col-md-7 @error('nominee_name') is-invalid @enderror" id="nominee_name" type="text"  value="{{ old('nominee_name') }}" autofocus>
                                                @error('nominee_name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="nominee_dob" class="col-xl-3 col-md-4"><span>*</span> Nominee DOB:</label>
                                                <input name="nominee_dob" class="form-control col-xl-8 col-md-7 @error('nominee_dob') is-invalid @enderror" id="nominee_dob" type="date"  value="{{ old('nominee_dob') }}" autofocus>
                                                @error('nominee_dob')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                        
                                    </div>
                                    <div class="form-group row">
                                        
                                        <div class="col-md-6">
                                            <div class="row">
                                                
                                                <label for="nominee_relation" class="col-xl-3 col-md-4"><span>*</span> Relation:</label>
                                                <input name="nominee_relation" class="form-control col-xl-8 col-md-7 @error('nominee_relation') is-invalid @enderror" id="nominee_relation" type="text"  value="{{ old('nominee_relation') }}" autofocus>
                                                @error('nominee_relation')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="row">
                                                <label for="nominee_aadhar_no" class="col-xl-3 col-md-4"><span>*</span> Aadhar No:</label>
                                                <input name="nominee_aadhar_no" class="form-control col-xl-8 col-md-7 @error('nominee_aadhar_no') is-invalid @enderror" id="nominee_aadhar_no" type="text"  value="{{ old('nominee_aadhar_no') }}" autofocus>
                                                @error('nominee_aadhar_no')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-6">
                                                <div class="row">
                                                    <label for="nominee_mobile" class="col-xl-3 col-md-4"><span>*</span> Mobile:</label>
                                                    <input name="nominee_mobile" class="form-control col-xl-8 col-md-7 @error('nominee_mobile') is-invalid @enderror" id="nominee_mobile" type="text"  value="{{ old('nominee_mobile') }}" autofocus>
                                                    @error('nominee_mobile')
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong>{{ $message }}</strong>
                                                        </span>
                                                    @enderror
                                                </div>
                                        </div>
                                    </div>
                                  
                                    <div class="pull-right">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>
                                </form>
                            </div>
                           
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Container-fluid Ends-->

</div>
@endsection