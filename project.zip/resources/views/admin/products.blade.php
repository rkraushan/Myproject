@extends('admin.dashboard')
@section('content')
<div class="page-body">

            <!-- Container-fluid starts-->
            <div class="container-fluid">
                <div class="page-header">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="page-header-left">
                                <h3>Product List
                                    <small>PkEnterprises Admin panel</small>
                                </h3>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <ol class="breadcrumb pull-right">
                                <li class="breadcrumb-item"><a href="{{url('/')}}"><i data-feather="home"></i></a></li>
<!--                                <li class="breadcrumb-item">Physical</li>-->
                                <li class="breadcrumb-item active">Product List</li>
                            </ol>
                            <button><a href="{{url('/admin/create-product')}}">Add New Product</a></button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Container-fluid Ends-->
            <!-- Container-fluid starts-->
            <div class="container-fluid">
                <div class="row products-admin ratio_asos">
                   @foreach($products as $product)
                    <div class="col-xl-3 col-sm-6">
                        <div class="card">
                            <div class="card-body product-box" style="height: 440px;">
                                <div class="img-wrapper">
                                    <div class="front">
                                        <a href="#"><img src="{{asset('productImage/'.$product->image)}}" class="img-fluid blur-up lazyload bg-img" alt=""></a>
                                        
                                    </div>
                                </div>
                                <div class="product-detail">
                                    <a href="#">
                                        <h6>{{$product->name}}</h6>
                                    </a>
                                    <p>Uses: {{wordwrap($product->description,20)}}</p>
                                    <h4>Rs {{$product->price}}</h4>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach

                </div>
            </div>
            <!-- Container-fluid Ends-->

        </div>

@endsection
