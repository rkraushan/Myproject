@extends('admin.dashboard')
@section('content')
<link rel="stylesheet" type="text/css" href="https://unpkg.com/treeflex/dist/css/treeflex.css">
<style type="text/css">
  .example .tf-nc {
  /* css here */
}

.tf-custom .tf-nc:before,
.tf-custom .tf-nc:after {
  /* css here */
}

.tf-custom li li:before {
  /* css here */
}
</style>
    <div class="page-body">

        <!-- Container-fluid starts-->
        <div class="container-fluid">
            <div class="page-header">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="page-header-left">
                            <h3>JLM Members
                                <small> Admin panel</small>
                            </h3>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <ol class="breadcrumb pull-right">
                            <li class="breadcrumb-item"><a href="{{url('admin')}}"><i data-feather="home"></i></a></li>
                            <li class="breadcrumb-item">Members</li>
                            
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <!-- Container-fluid Ends-->

        <!-- Container-fluid starts-->
        <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                   <?php 
                     $level1= getUsersbySponserId($admin->self_id);
                    ?>
                    
                    
                    <div class="tf-tree example">
                        <ul>
                            <li>
                                <span class="tf-nc">{{$admin->name}}</span>
                                <ul>
                                  @foreach($level1 as $level)
                                  <li>
                                    <span class="tf-nc">{{$level->name}}</span>
                                    <ul>
                                    <?php 
                                        $level2= getUsersbySponserId($level->self_id);
                                    ?> 
                                      @foreach($level2 as $level21)
                                      <li><span class="tf-nc">{{$level21->name}}</span></li>
                                      @endforeach
                                    </ul>
                                  </li>
                                  @endforeach
<!--                                  <li>
                                    <span class="tf-nc">3</span>
                                    <ul>
                                      <li><span class="tf-nc">7</span></li>
                                      <li><span class="tf-nc">8</span></li>
                                    </ul>
                                  </li>-->
                                </ul>
                            </li>
                        </ul>
                  </div>
                </div>
            </div>
        </div>
        <!-- Container-fluid Ends-->
    </div>

@endsection

