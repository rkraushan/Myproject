@extends('admin.dashboard')
@section('content')
    <div class="page-body">

        <!-- Container-fluid starts-->
        <div class="container-fluid">
            <div class="page-header">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="page-header-left">
                            <h3>JLM Members
                                <small> Admin panel</small>
                            </h3>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <ol class="breadcrumb pull-right">
                            <li class="breadcrumb-item"><a href="{{url('admin')}}"><i data-feather="home"></i></a></li>
                            <li class="breadcrumb-item">Members</li>
                            
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <!-- Container-fluid Ends-->

        <!-- Container-fluid starts-->
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <h5>Details</h5>
                    <div class="btn-popup pull-right">
                        <a href="{{url('admin/new-user')}}" class="btn btn-secondary">Create User</a>
                    </div>
                </div>
                <div class="card-body">
                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th>SN.</th>
                                <th>Sponsor ID</th>
                                <th>Sponsor Name</th>
                                <th>Member Id</th>
                                <th>Name</th>
                                <th>Father</th>
                                <th>Mobile</th>
                                <th>Address</th>
                                <th>A/C Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                             @php $i=0;@endphp
                            @foreach($users as $user)
                             @php $i++;@endphp
                                <tr>
                                    <td>{{ $i }}</td>
                                    <td>{{ $user->sponsor_id }}</td>
                                    <td>{{ $user->sponsor_name }}</td>
                                    <td>{{ $user->self_id }}</td>
                                    <td>{{ $user->name }}</td>
                                    <td>{{ $user->father_name }}</td>
                                    <td>{{ $user->mobile_no }}</td>
                                    <td>{{ $user->village .' '.$user->district }}</td>
                                    <td><?php if($user->payment_status == 0){
                                        echo "<span  class='btn btn-warning'>IN ACTIVE</span>";
                                    }else{
                                        echo "<span style='color:white' class='btn btn-success'> ACTIVE</span>";
                                    }
?></td>
                                   
                                    <td><a href="{{url('admin/view-user/'.$user->id)}}" >View</a></td>
                                </tr>
                            @endforeach
                        </tbody>

                    </table>
              
                </div>
            </div>
        </div>
        <!-- Container-fluid Ends-->
    </div>

@endsection

