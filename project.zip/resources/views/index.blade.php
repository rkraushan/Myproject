@extends('frontend')
@section('content')
<section class="home-banner-2020mar5" >
    <div class="container banner-container-2020mar5">
        <div class="banner-2020mar-img5" >
            <img  class="lazyload ctbannerImg" src="image/contact-bg-2.png" style=" height: 443px;"/>
        </div> <!-- Close banner-2020mar-img -->
        <div class="banner-2020mar-cnt5">
            <h1>PK Enterprises - #Jeevan Life Marketing</h1>
            <p>The foremost MLM Software development company that can eliminate all your network marketing concerns in no time. It is the one stop solution for the rising complexity in your multi level marketing business. Hence, this MLM program deals with downline management to facilitation in complex financial calculations.</p>
	
            <!-- <a class="banner-view-demo" href="preset-demo.html">View Demo<i class="fa fa-angle-right" aria-hidden="true"></i><i class="fa fa-angle-right" aria-hidden="true"></i></a>
            <p><a class="version" href="version-history.html"><span>New Version</span><i>11.0</i></a></p> -->
        </div>        
    </div>
    <div class="banner-bottom-2020mar5" >
        <div class="container">
        <div class="">
            <h3>Get started business with me<span>.</span></h3>
            <a href="{{route('login')}}" class="">Start now<i class="fa fa-angle-right" aria-hidden="true"></i><i class="fa fa-angle-right" aria-hidden="true"></i>
            </a>
            </div>
        </div>
    </div>
</section>

<section class="text-center home-tabs-header-section  section-mlm">
    <div class="container">      
	    <h2>The fastest way to grow Direct Selling Business with PK Enterprises - The multilevel marketing business and medicine!
	    </h2>
        <div class="row">
                <div class="col-sm-12 col-md-12 wel-cnt">
                    <p><p>PK Enterprises is a leader in providing the explicitly designed MLM marketing  business with a wide range of MLM Compensation Plans, Add-ons and various customizations to meet the different businesses of various clients. Our direct selling products holds a unique position in MLM Business Industry.</p>
					</p>
                </div>
        </div>
    </div>
</section>

<section class="new_popular_section lazy">
    <div class="container">
    	<div class="new_popular_grid">
    		<div class="new_popular_img">
    		</div>
    		<div class="new_popular_cnt">
    			<div class="new_popular-head">
        		<div class="new_popular-title"><h3 class="heading">How we works ?</h3></div>
        		<p>We have a number of add ons developed to satisfy the huge diversity in the requirements of our marketing customers. Choose the required  add-on to be integrated in your software.</p>
        		</div>      
        	<div class="new_popular_container">
            <a class="nps">
                <span class="nps-img bg-Backup_System"></span>
                <span class="nps-cnt">Backup Facility</span>
            </a>
            <a class="nps" href="javacript:void(0);">
                <span class="nps-img bg-Replicating_Website"></span>
                <span class="nps-cnt">Replicating Data</span>
            </a>
            <a class="nps" href="javacript:void(0);">
                <span class="nps-img bg-Automatic_Payment"></span>
                <span class="nps-cnt">Easy Payment</span>
            </a>
            <a class="nps" href="javacript:void(0);">
                <span class="nps-img bg-E_wallet"></span>
                <span class="nps-cnt">E-wallet</span>
            </a>
            <a class="nps" href="javacript:void(0);">
                <span class="nps-img bg-Mobile_Apps"></span>
                <span class="nps-cnt">Mobile </span>
            </a>
            <a class="nps" href="javacript:void(0);">
                <span class="nps-img bg-E_Commerce"></span>
                <span class="nps-cnt">Buy Health Product</span>
            </a>
            <a class="nps" href="javacript:void(0);">
                <span class="nps-img bg-SMS"></span>
                <span class="nps-cnt">SMS</span>
            </a>
            <a class="nps" href="javacript:void(0);">
                <span class="nps-img bg-Multilingual"></span>
                <span class="nps-cnt">Support</span>
            </a>
        	</div>    
		</div></div>
    </div></section> 

 





<section class="section why-shoose-us">
<div class="main-container container">
    <div class="why-shoose-us-head">
    <h3 class="text-uppercase heading border-bottom mb-4 sub_g">Why Should You Choose Us?</h3>
    <p>We are a team of making natural products and creating marketing chain. PK Enterprises has been pioneers in the marketing strategy, research with natural Ayurvedic health products.</p>
</div>
    <div class="why-shoose-us-grid">
        <div class="why-shoose-us-block">
        <div class="why-shoose-us-img"><img alt="High-End Features" class="lazy" data-src="image/why_1.jpg"></div>
        <div class="why-shoose-us-cnt"><div><h3>High-End Features</h3><p>PK Enterprises is the best MLM Software integrated with high features like e-pin, e-wallet, e-commerce integration and more.</p></div></div>
    </div>
        <div class="why-shoose-us-block">
        <div class="why-shoose-us-img"><img alt="E-commerce Solution" class="lazy" data-src="image/why_2.jpg"></div>
        <div class="why-shoose-us-cnt"><div><h3>E-commerce Solution</h3><p>PK Enterprises is integrated with modern  e-commerce solutions and opencart integration.</p></div></div>
    </div>
        
</div>
<div class="why-shoose-us-grid why-shoose-us-grid2">
        <div class="why-shoose-us-block">
        <div class="why-shoose-us-img"><img alt="Super Crafted" class="lazy" data-src="image/why_3.jpg"></div>
        <div class="why-shoose-us-cnt"><div><h3>Super Crafted</h3><p>PK Enterprises is crafted with the most valuable marketing business </p></div></div>
    </div>
        <div class="why-shoose-us-block">
        <div class="why-shoose-us-img"><img alt="Highly Secured" class="lazy" data-src="image/why_4.jpg"></div>
        <div class="why-shoose-us-cnt"><div><h3>Highly Secured</h3><p>PK Enterprises is provided with premium security features which can save you from any security issues.</p></div></div>
    </div>
    </div>
<div class="why-more-link"><a href="{{url('about')}}" class="primary-btn">View All Features</a></div>
</div>
</section>

@endsection