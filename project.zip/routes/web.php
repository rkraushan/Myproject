<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/our-products', function () {
//    return view('products');
//});
Route::get('/', 'FrontendController@index');
Route::get('about', 'FrontendController@about');
Route::get('team', 'FrontendController@team');
Route::get('contact', 'FrontendController@contact');
Route::get('our-products', 'FrontendController@getProducts');
Auth::routes();

//Route::get('/home', 'HomeController@index')->name('home');
Route::group(['prefix' => 'user','middleware' => 'App\Http\Middleware\User'], function () {

Route::get('/', 'HomeController@index')->name('user');
Route::get('help', 'HomeController@helpAdmin');
Route::get('/change-password','HomeController@showChangePasswordForm');
Route::post('/changePassword','HomeController@changePassword');
});

Route::group(['prefix' => 'admin','middleware' => 'App\Http\Middleware\Admin'], function () {

Route::get('/', 'AdminController@index')->name('admin');
Route::get('help', 'AdminController@helpAdmin');
Route::get('/change-password','AdminController@showChangePasswordForm');
Route::post('/changePassword','AdminController@changePassword');

Route::get('products', 'AdminController@getProducts');
Route::get('create-product', 'AdminController@createProduct');
Route::post('/create-product','AdminController@storeProduct');

Route::get('new-user', 'AdminController@newUser');
Route::post('reg-new-user', 'AdminController@registerUser');
Route::get('users', 'AdminController@getUsers');
Route::get('view-user/{id}', 'AdminController@viewUserById');

Route::get('tree-view', 'AdminController@getTreeView');
Route::post('update-new-user/{userId}', 'AdminController@updateUser');
});
