<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $table ="orders";
    protected $fillable = [
        'user_id','product_id','quantity','amount','address','city','state','pincode','order_status',
        'payment_id','transaction_id','payment_mode'
    ];
}
