<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
       'sponsor_id','sponsor_name', 'citizen','name', 'email', 'password','gender','father_name','pan_no',
        'pan_document','dob','village','post_office','police_station', 'district', 'state', 'pincode',
        'aadhar_no', 'aadhar_document', 'mobile_no','profile_pic', 'signature', 'account_holder_name',
        'branch_name', 'branch_ifsc','account_no', 'bank_name', 'nominee_name', 'nominee_dob', 'nominee_mobile',
        'nominee_relation','nominee_aadhar_no','payment_status','payment_id','user_type'
    ];
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
}
