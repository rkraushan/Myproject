<?php
 use App\User;
 
function getUsersbySponserId($sponsorId){
    $data = User::where('sponsor_id',$sponsorId)->get();
    return $data; 
}
function totalUser(){
    return User::where('user_type','user')->count();
}


?>