<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Product;
use File;
use App\User;
use Session;
use Auth;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $data['page_title'] = 'User Dashboard';
        $data['users'] = User::where('user_type','user')->inRandomOrder()->limit(5)->get();
        return view('user.index',$data);
    }
    public function newUser(){
        $data['page_title'] = 'New User';

        return view('user.new-user',$data);
    }
    public function registerUser(Request $request,User $user){
        $this->validate($request,[
            'citizen'=>'required', 
            'gender'=>'required',
            'name'=>'required',
          //  'email'=>'required',
            'mobile_no'=>'required|unique:users',
            'password'=>'required',
            'father_name'=>'required',
            'aadhar_no'=>'required',
           /* 'pan_no'=>'required',
            'dob'=>'required',
            'village'=>'required',
            'post_office'=>'required',
            'police_station'=>'required',
            'district'=>'required',
            'state'=>'required',
            'pincode'=>'required',
            'profile_pic'=>'required',
            'signature'=>'required',
            'account_holder_name'=>'required',
            'branch_name'=>'required',
            'branch_ifsc'=>'required',
            'account_no'=>'required',
            'bank_name'=>'required',
            'nominee_name'=>'required',
            'nominee_dob'=>'required',
            'nominee_mobile'=>'required',
            'nominee_relation'=>'required',
            'nominee_aadhar_no'=>'required',
            */
         ]);
         
        if(checkSponsorId($request->sponsor_id) == 0){
            session()->flash('message','Sponsor Id does not exist. Please use different id. !!');
            session()->flash('type','error');
            session()->flash('title','Oops');
            return redirect()->back()->withInput($request->input());
        } 
        if(getUserAccountPaymentStatus($request->sponsor_id) == 0){
            session()->flash('message','Sponsor Id is not activated. Please activate your account first !!');
            session()->flash('type','error');
            session()->flash('title','Oops');
            return redirect()->back()->withInput($request->input());
        } 
        
        if(countSponserIdLimit($request->sponsor_id) >=3){
            session()->flash('message','Please change Sponsor id. You can not add more than 3 users. !!');
            session()->flash('type','error');
            session()->flash('title','Oops');
            return redirect()->back()->withInput($request->input());
        }
        
        $insertdata = $user->insertData($request->all());
        
        if($request->payment_mode == "offline"){
        
        $updatePaymentStatus = $user->updateSingleData($insertdata, 'payment_status', 0);
        $updatePaymentmode   = $user->updateSingleData($insertdata, 'payment_mode', 'offline');
        
        session()->flash('message','Users successfully added  !!');
        session()->flash('type','success');
        session()->flash('title','Success');
        return redirect('user/users');
       }else{
           Session::put('userId', $insertdata);

           return redirect()->route('payment');
       }
    }
    public function updateUser(Request $request, $id){
        
        $user =User ::where('id',$id)->update([
            'sponsor_id'=>$request->sponsor_id,
            'sponsor_name'=>$request->sponsor_name,
            'citizen'=>$request->citizen,
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>Hash::make($request->password),
            'gender'=>$request->gender,
            'father_name'=>$request->father_name,
            'pan_no'=>$request->pan_no,
            'dob'=>$request->dob,
            'village'=>$request->village,
            'post_office'=>$request->post_office,
            'police_station'=>$request->police_station,
            'district'=>$request->district,
            'state'=>$request->state,
            'pincode'=>$request->pincode,
            'aadhar_no'=>$request->aadhar_no,
            'mobile_no'=>$request->mobile_no,
            'account_holder_name'=>$request->account_holder_name,
            'branch_name'=>$request->branch_name,
            'branch_ifsc'=>$request->branch_ifsc,
            'account_no'=>$request->account_no,
            'bank_name'=>$request->bank_name,
            'nominee_name'=>$request->nominee_name,
            'nominee_dob'=>$request->nominee_dob,
            'nominee_mobile'=>$request->nominee_mobile,
            'nominee_relation'=>$request->nominee_relation,
            'nominee_aadhar_no'=>$request->nominee_aadhar_no,
            'branch_ifsc'=>$request->branch_ifsc,
        ]);
        session()->flash('message','Users successfully updated  !!');
        session()->flash('type','success');
        session()->flash('title','Success');
        return redirect('user/users');   
    }

    public function getUsers(){
       // $data['users'] = User::where('user_type','user')->orderByDesc('id')->get();
        $data['users'] = User::where('user_type','user')->where('sponsor_id',Auth::user()->self_id)->get();
        return view('user.users',$data);
    }
    public function viewUserById(Request $request,$id){
        $data['user'] = User::where('id',$id)->first();
        return view('user.view-user',$data);
    }
    public function getUserDetails($userId){
        $data['page_title'] = 'User Details';
        $data['user'] = User::where('id',$userId)->first();
        return view('user.user-details',$data);
    }
    public function getTreeView(Request $request){
        $data['page_title'] = 'Network';
        $data['admin'] = User::where('user_type','admin')->first();
        $data['users'] = User::where('user_type','user')->get();
        return view('user.tree-view',$data); 
    }
    public function editProfile(){
        $data['page_title'] = 'Edit Profile';
        $data['user'] = User::where('id',Auth::id())->first();
        return view('user.edit-profile',$data);
    }
    public function updateProfile(Request $request){
        $user =User ::where('id',Auth::id())->update([
            'citizen'=>$request->citizen,
            'gender'=>$request->gender,
            'name'=>$request->name,
            'father_name'=>$request->father_name,
            'email'=>$request->email,
           // 'password'=>Hash::make($request->password)
            ]);
        
        if($request->profile_pic){
            $image = $request->profile_pic;
            $fileContents = file_get_contents($request->profile_pic);
            $filename = $image->getClientOriginalName();
            $storagePath='assets/users/'.$filename;
            File::put($storagePath, $fileContents);
            $user =User ::where('id',Auth::id())->update(['profile_pic'=>$filename]);    
        }
        session()->flash('message','Your Profile updated successfully !!');
        session()->flash('type','success');
        session()->flash('title','Success');
        
        return redirect()->back();
        
    }
    public function getChangePasswordView(Request $request){
        $data['page_title'] = 'Change Password view';
        return view('user.change-password',$data);
    }
    public function changePassword(Request $request){
        $this->validate($request,[
        
            'current-password' => 'required',
            'new-password' => 'required|string|min:8',
        ]);
        if (!(Hash::check($request->get('current-password'), Auth::user()->password))){
            
            session()->flash('message','Your current password does not matches with the password you provided. Please try again. !!');
            session()->flash('type','error');
            session()->flash('title','Oops');
            
            return redirect()->back();
        }

        if(strcmp($request->get('current-password'), $request->get('new-password')) == 0){
            //Current password and new password are same
            session()->flash('message','New Password cannot be same as your current password. Please choose a different password. !!');
            session()->flash('type','error');
            session()->flash('title','Oops');
            
            return redirect()->back();
        }
        
        
    
        //Change Password
        User::where('id',Auth::id())->update(['password'=>Hash::make($request->get('new-password'))]);
        
        session()->flash('message','Password successfully changed !!');
        session()->flash('type','success');
        session()->flash('title','Success');
        return redirect('/user');
       
    }
}
