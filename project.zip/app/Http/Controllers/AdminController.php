<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Product;
use File;
use App\User;
class AdminController extends Controller{
    
    public function __construct(){
        $this->middleware('auth');
    }
    public function index(){
    
    	$data['page_title'] = 'Admin Dashboard';
        $data['users'] = User::where('user_type','user')->inRandomOrder()->limit(5)->get();
        return view('admin.index',$data);
    }
    public function getProducts(Request $request){
        $data['page_title'] = 'Product';
        $data['products'] = Product::orderByDesc('id')->get();
        return view('admin.products',$data);
    }
    public function createProduct(Request $request){
        $data['page_title'] = 'Create Product';
        
        return view('admin.create-product',$data);
    }
    public function storeProduct(Request $request){
        //$data['page_title'] = 'Create Product';
        $this->validate($request,[
        'name'=>'required', 
        'price'=>'required',
        'image'=>'required',  
         ]);
        $product = new Product;
        if($request->image){
            $image = $request->image;
            $fileContents = file_get_contents($request->image);
            $filename = $image->getClientOriginalName();
            $storagePath='productImage/'.$filename;
            File::put($storagePath, $fileContents);
            $product->image = $filename;
        }
        $product->name= $request->name;
        $product->description= $request->description;
        $product->details= $request->details;
        $product->price= $request->price;
        $product->save();
        
        session()->flash('message','Product added successfully !!');
        session()->flash('type','success');
        session()->flash('title','Success');
        
        return redirect('admin/products');
    }
    public function newUser(){
        $data['page_title'] = 'New User';

        return view('admin.new-user',$data);
    }
    public function registerUser(Request $request){
        $this->validate($request,[
            'citizen'=>'required', 
            'name'=>'required',
          //  'email'=>'required',
            'password'=>'required',
            'gender'=>'required',
            'father_name'=>'required',
           // 'pan_no'=>'required',
            'dob'=>'required',
            'village'=>'required',
            'post_office'=>'required',
            'police_station'=>'required',
            'district'=>'required',
            'state'=>'required',
            'pincode'=>'required',
           // 'aadhar_no'=>'required',
            'mobile_no'=>'required|unique:users',
           // 'profile_pic'=>'required',
           // 'signature'=>'required',
          /*  'account_holder_name'=>'required',
            'branch_name'=>'required',
            'branch_ifsc'=>'required',
            'account_no'=>'required',
            'bank_name'=>'required',
            'nominee_name'=>'required',
            'nominee_dob'=>'required',
            'nominee_mobile'=>'required',
            'nominee_relation'=>'required',
            'nominee_aadhar_no'=>'required',
            */
         ]);
       // print "<pre>";
      //  print_r($request->all());
      //  print "</pre>";
        
        $user = new User();
        $user->sponsor_id = $request->sponsor_id;
        $user->sponsor_name = $request->sponsor_name;
        $user->citizen = $request->citizen;
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->gender = $request->gender;
        $user->father_name = $request->father_name;
        $user->pan_no = $request->pan_no;
        $user->dob = $request->dob;
        $user->village = $request->village;
        $user->post_office = $request->post_office;
        $user->police_station = $request->police_station;
        $user->district = $request->district;
        $user->state = $request->state;
        $user->pincode = $request->pincode;
        $user->aadhar_no = $request->aadhar_no;
        $user->mobile_no = $request->mobile_no;
        if($request->profile_pic){
            $image = $request->profile_pic;
            $fileContents = file_get_contents($request->profile_pic);
            $filename = $image->getClientOriginalName();
            $storagePath='assets/users/'.$filename;
            File::put($storagePath, $fileContents);
            $user->profile_pic = $filename;
        }
        if($request->signature){
            $image = $request->signature;
            $fileContents = file_get_contents($request->signature);
            $filename = $image->getClientOriginalName();
            $storagePath='assets/users/'.$filename;
            File::put($storagePath, $fileContents);
            $user->signature = $filename;
        }
       // $user->profile_pic = $request->profile_pic;
      //  $user->signature = $request->signature;
        $user->account_holder_name = $request->account_holder_name;
        $user->branch_name = $request->branch_name;
        $user->branch_ifsc = $request->branch_ifsc;
        $user->account_no = $request->account_no;
        $user->bank_name = $request->bank_name;
        $user->nominee_name = $request->nominee_name;
        $user->nominee_dob = $request->nominee_dob;
        $user->nominee_mobile = $request->nominee_mobile;
        $user->nominee_relation = $request->nominee_relation;
        $user->nominee_aadhar_no = $request->nominee_aadhar_no;
        $user->user_type = 'user';
        $user->save();
        $lastId = $user->id;
        $selfid='JLM'.date("y").'u'.$lastId;
        $update = User::where('id',$lastId)
                ->update([
                     'self_id'=>$selfid          
                ]);
        session()->flash('message','Users successfully added  !!');
        session()->flash('type','success');
        session()->flash('title','Success');
        return redirect('admin/users');
    }
    public function updateUser(Request $request, $id){
        
        $user =User ::where('id',$id)->update([
            'sponsor_id'=>$request->sponsor_id,
            'sponsor_name'=>$request->sponsor_name,
            'citizen'=>$request->citizen,
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>Hash::make($request->password),
            'gender'=>$request->gender,
            'father_name'=>$request->father_name,
            'pan_no'=>$request->pan_no,
            'dob'=>$request->dob,
            'village'=>$request->village,
            'post_office'=>$request->post_office,
            'police_station'=>$request->police_station,
            'district'=>$request->district,
            'state'=>$request->state,
            'pincode'=>$request->pincode,
            'aadhar_no'=>$request->aadhar_no,
            'mobile_no'=>$request->mobile_no,
            'account_holder_name'=>$request->account_holder_name,
            'branch_name'=>$request->branch_name,
            'branch_ifsc'=>$request->branch_ifsc,
            'account_no'=>$request->account_no,
            'bank_name'=>$request->bank_name,
            'nominee_name'=>$request->nominee_name,
            'nominee_dob'=>$request->nominee_dob,
            'nominee_mobile'=>$request->nominee_mobile,
            'nominee_relation'=>$request->nominee_relation,
            'nominee_aadhar_no'=>$request->nominee_aadhar_no,
            'branch_ifsc'=>$request->branch_ifsc,
        ]);
        session()->flash('message','Users successfully updated  !!');
        session()->flash('type','success');
        session()->flash('title','Success');
        return redirect('admin/users');   
    }

    public function getUsers(){
       // $data['users'] = User::where('user_type','user')->orderByDesc('id')->get();
        $data['users'] = User::where('user_type','user')->get();
        return view('admin.users',$data);
    }
    public function viewUserById(Request $request,$id){
        $data['user'] = User::where('id',$id)->first();
        return view('admin.view-user',$data);
    }
    public function getTreeView(Request $request){
        $data['page_title'] = 'Network';
        $data['admin'] = User::where('user_type','admin')->first();
        $data['users'] = User::where('user_type','user')->get();
        return view('admin.tree-view',$data); 
    }
}