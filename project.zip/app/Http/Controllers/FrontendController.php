<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Product;
use File;
class FrontendController extends Controller{
    
    public function __construct(){
       // $this->middleware('auth');
    }
    public function index(){
    
    	$data['page_title'] = 'Website';
        return view('index',$data);
    }
    public function about(){
    
    	$data['page_title'] = 'About';
        return view('about',$data);
    }
    public function team(){
    
    	$data['page_title'] = 'Website';
        return view('team',$data);
    }
    public function contact(){
    
    	$data['page_title'] = 'Website';
        return view('contact',$data);
    }
    public function getProducts(Request $request){
        $data['page_title'] = 'Product';
        $data['products'] = Product::orderByDesc('id')->get();
        return view('products',$data);
    }
    public function createProduct(Request $request){
        $data['page_title'] = 'Create Product';
        
        return view('admin.create-product',$data);
    }
    public function storeProduct(Request $request){
        //$data['page_title'] = 'Create Product';
        $this->validate($request,[
        'name'=>'required', 
        'price'=>'required',
        'image'=>'required',  
         ]);
        $product = new Product;
        if($request->image){
            $image = $request->image;
            $fileContents = file_get_contents($request->image);
            $filename = $image->getClientOriginalName();
            $storagePath='productImage/'.$filename;
            File::put($storagePath, $fileContents);
            $product->image = $filename;
        }
        $product->name= $request->name;
        $product->description= $request->description;
        $product->details= $request->details;
        $product->price= $request->price;
        $product->save();
        
        return redirect('admin/products');
    }
    
}